export const PLATFORMS = {
  MICROSOFT: 'Microsoft',
  AWS: 'Amazon AWS',
  ATLASSIAN: 'Atlassian',
};
