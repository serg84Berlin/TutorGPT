export const CATEGORIES = {
  CLOUD: 'Cloud',
  TOOLS: 'Tools',
  SECURITY: 'Security',
  AI: 'AI & Machine Learning',
};
